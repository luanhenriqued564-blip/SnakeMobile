# Calculadora

Um aplicativo incrível criado com IA

## 📱 Como Instalar no Android/iOS

### Opção 1: Hospedagem Online (Recomendado)

1. **GitHub Pages (Grátis)**:
   - Crie um repositório no GitHub
   - Faça upload de todos os arquivos
   - Ative GitHub Pages nas configurações
   - Acesse pelo celular: https://seuusuario.github.io/seurepositorio
   - Clique em "Adicionar à tela inicial"

2. **Netlify ou Vercel (Grátis)**:
   - Crie conta em netlify.com ou vercel.com
   - Arraste a pasta do projeto
   - Acesse a URL gerada pelo celular
   - Instale como app

### Opção 2: Teste Local

1. Instale "Web Server for Chrome" ou similar
2. Abra os arquivos localmente
3. Acesse pelo IP local no celular

## 🎯 Recursos PWA

✅ Funciona offline
✅ Instalável como app nativo
✅ Ícone na tela inicial
✅ Tela cheia (sem barra do navegador)
✅ Notificações (se implementado)

## 🔧 Arquivos Incluídos

- index.html - Seu aplicativo
- manifest.json - Configurações PWA
- service-worker.js - Funcionalidade offline
- icon-192.png e icon-512.png - Ícones do app

## 📝 Observações

- Requer HTTPS para funcionar (GitHub Pages/Netlify já tem)
- Teste no Chrome/Edge/Safari mobile
- Para atualizar, altere a versão no service-worker.js

Desenvolvido com ❤️ usando IA
